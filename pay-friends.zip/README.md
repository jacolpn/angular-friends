# PayFriends
An project.

# Generate build:
$ `ng build --prod --base-href="/"`

# Angular CLI:
$ `ng --version`
$ `Angular CLI: 12.0.3`

# NodeJS:
$ `node -v`
$ `v15.11.0`

# JSON Server:
$ `npm install -g json-server`
$ `json-server .\db.json`

# OBS:
$ Em caso de erro ao inciar o projeto, deletar o `package-lock.json`.
